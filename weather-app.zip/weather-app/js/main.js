'use strict';

var lat;
var lng;
var weatherConditions = new XMLHttpRequest();
var weatherForecast = new XMLHttpRequest();
var conditionsObject;
var forecastObject;

navigator.geolocation.getCurrentPosition(function(position) {
    console.log(position.coords.latitude, position.coords.longitude);
    lat = position.coords.latitude;
    lng = position.coords.longitude;
});

$.getJSON('http://www.geoplugin.net/extras/postalcode.gp?lat=' + lat + '&long=' + lat, function(data) {
    console.log(data);
});

weatherConditions.onload = function () {
    if (weatherConditions.status === 200) {
        conditionsObject = JSON.parse(weatherConditions.responseText);
        console.log(conditionsObject);
        // DISPLAY CURRENT WEATHER ICON
        var imagePath = forecastObject.forecast.simpleforecast.forecastday[0].icon_url;
        document.getElementById('icon').src = imagePath;
        document.getElementById('location').innerHTML = conditionsObject.current_observation.display_location.full;
        document.getElementById('weather').innerHTML = conditionsObject.current_observation.weather;
        document.getElementById('temperature').innerHTML = conditionsObject.current_observation.temp_f + '°F';
    } // end if
}; // end function

weatherForecast.onload = function () {
    if (weatherForecast.status === 200) {
        forecastObject = JSON.parse(weatherForecast.responseText);
        console.log(forecastObject);
        document.getElementById('description').innerHTML = forecastObject.forecast.txt_forecast.forecastday[0].fcttext;
        // Day 1
        var imagePath = forecastObject.forecast.simpleforecast.forecastday[1].icon_url;
        document.getElementById('1-1').innerHTML = forecastObject.forecast.simpleforecast.forecastday[1].date.weekday;
        document.getElementById('1-2').src = imagePath;
        document.getElementById('1-3').innerHTML = forecastObject.forecast.simpleforecast.forecastday[1].high.fahrenheit + '°';
        document.getElementById('1-4').innerHTML = forecastObject.forecast.simpleforecast.forecastday[1].low.fahrenheit + '°';
        // Day 2
        var imagePath = forecastObject.forecast.simpleforecast.forecastday[2].icon_url;
        document.getElementById('2-1').innerHTML = forecastObject.forecast.simpleforecast.forecastday[2].date.weekday;
        document.getElementById('2-2').src = imagePath;
        document.getElementById('2-3').innerHTML = forecastObject.forecast.simpleforecast.forecastday[2].high.fahrenheit + '°';
        document.getElementById('2-4').innerHTML = forecastObject.forecast.simpleforecast.forecastday[2].low.fahrenheit + '°';
        // Day 3
        var imagePath = forecastObject.forecast.simpleforecast.forecastday[3].icon_url;
        document.getElementById('3-1').innerHTML = forecastObject.forecast.simpleforecast.forecastday[3].date.weekday;
        document.getElementById('3-2').src = imagePath;
        document.getElementById('3-3').innerHTML = forecastObject.forecast.simpleforecast.forecastday[3].high.fahrenheit + '°';
        document.getElementById('3-4').innerHTML = forecastObject.forecast.simpleforecast.forecastday[3].low.fahrenheit + '°';

    } // end if
}; // end function

// Get weather by location
function getWeather() {
    var zip = document.getElementById('zip').value;

    if (zip === '') {
        zip = '32816';
    }

    var conditionsPath = 'https://api.wunderground.com/api/6de3f7d935c0a6e1/conditions/q/' + zip + '.json';
    var forecastPath = 'https://api.wunderground.com/api/6de3f7d935c0a6e1/forecast/q/' + zip + '.json';

    // Get Conditions
    weatherConditions.open('GET', conditionsPath, true);
    weatherConditions.responseType = 'text';
    weatherConditions.send(null);

    // Get Forecast
    weatherForecast.open('GET', forecastPath, true);
    weatherForecast.responseType = 'text';
    weatherForecast.send();
} // end function

getWeather();

